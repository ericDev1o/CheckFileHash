namespace StatsTennisAPI.tests;

public class StatsTennisAPIControllerTest
{
    //[Fact]
    public bool TestGet()
    {
        // Arrange
        /*var application = new WebApplicationFactory<>.WithWebHostBuilder(
            builder =>
            {

            }
        );*/
        // Act

        // Assert
        return false;
    }
}