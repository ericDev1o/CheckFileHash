namespace StatsTennisAPI;

public class PlayerCountry
{
    //public Image Picture {get; set;}
    [DisallowNull]
    public string Code {get; set;} = "";
}